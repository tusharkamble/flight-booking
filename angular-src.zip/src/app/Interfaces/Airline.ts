interface Airline{
    Name: string,
    ContactNumber: string,
    Address: string
}