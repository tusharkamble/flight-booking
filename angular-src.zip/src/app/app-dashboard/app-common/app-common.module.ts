import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppCommonRoutingModule } from './app-common-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AppCommonRoutingModule
  ]
})
export class AppCommonModule { }
